<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('repository_items', function (Blueprint $table) {
            $table->json('seo_meta')->nullable()->after('status');
        });
    }

    public function down(): void
    {
        Schema::table('repository_items', function (Blueprint $table) {
            $table->dropColumn('seo_meta');
        });
    }
};
